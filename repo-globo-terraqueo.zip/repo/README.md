# Globo Interactivo de Noticias — ATLAS·26

Globo terráqueo 3D interactivo con noticias, clima y hora local en vivo por país.

## Stack

Bundle autocontenido (formato DC). Un solo archivo `index.html` (~2,7 MB) con React,
d3-geo, TopoJSON, la textura satelital y el directorio de 250 países embebidos en
base64. **Sin build step**: Vercel lo sirve como sitio estático.

## APIs en vivo (todas gratuitas, sin API key)

| Dato | Fuente | Fallback |
|---|---|---|
| Noticias por país | GDELT DOC 2.0 (escalera de 4 consultas) | Noticias curadas embebidas |
| Titulares globales | Wikimedia Featured Feed (es → en, hoy → ayer) | Noticias curadas embebidas |
| Clima | Open-Meteo | — |
| Zona horaria | TimeAPI.io | `utc_offset_seconds` de Open-Meteo |
| Ficha de país | REST Countries | Directorio embebido |
| Líderes | Wikidata SPARQL | — |

Todo degrada en silencio: sin conexión, el globo sigue funcionando con los datos embebidos.

## Refresco en vivo

- Reloj de zona horaria: cada 30 s
- Ficha del país seleccionado: cada 10 min (stale-while-revalidate, sin parpadeo)
- Titulares globales: cada 15 min

## Deploy

Push a `main` → Vercel publica automáticamente. No requiere configuración de build.

## Local

```bash
python3 -m http.server 8000   # y abrir http://localhost:8000
```

Abrirlo con doble clic (`file://`) también funciona: los recursos se leen de los Blobs
embebidos, no por `fetch`.
